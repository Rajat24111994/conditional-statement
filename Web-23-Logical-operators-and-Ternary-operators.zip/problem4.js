//Problem 4: Given 3 numbers (all different values), print which is greatest

let a= 10;
let b= 20;
let c= 5;


(a>b && a>c) ? console.log(a, "is greater") 
  : (b>c && b>a) ? console.log(b,"is greater")
  :console.log(c,"is greater");

